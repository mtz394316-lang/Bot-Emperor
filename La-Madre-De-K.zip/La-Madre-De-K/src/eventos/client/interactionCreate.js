const { Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require("discord.js");

module.exports = {
  name: Events.InteractionCreate,
  emiter: "on",
  run: async (client, interaction) => {
    if (interaction.isChatInputCommand()) {
      const command = client.slashCommands.get(interaction.commandName);
      try {
        await command.run(client, interaction);
      } catch (err) {
        console.log(err);
      }
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId.startsWith('estilo_selector_')) {
        const parts = interaction.customId.split('_');
        const messageId = parts[parts.length - 1];
        const userId = interaction.user.id;
        const estiloValue = interaction.values[0];

        const estilosMap = {
          'maestros_loki': 'Loki',
          'maestros_lavinho': 'Lavinho',
          'generacional_don_lorenzo': 'Don Lorenzo',
          'generacional_sae': 'Sae',
          'generacional_kaiser': 'Kaiser',
          'generacional_bunny': 'Bunny',
          'clase_mundial_charles': 'Charles',
          'clase_mundial_nel_isagi': 'NEL Isagi',
          'clase_mundial_nel_nagi': 'NEL Nagi',
          'clase_mundial_nel_rin': 'NEL Rin',
          'mitica_nel_bachira': 'NEL Bachira',
          'mitica_kunigami': 'Kunigami',
          'mitica_nel_reo': 'NEL Reo',
          'mitica_king': 'King',
          'mitica_aiku': 'Aiku',
          'mitica_shidou': 'Shidou',
          'mitica_yukimiya': 'Yukimiya',
          'legendario_nagi': 'Nagi',
          'legendario_karasu': 'Karasu',
          'legendario_otoya': 'Otoya',
          'epic_bachira': 'Bachira',
          'epic_gagamaru': 'Gagamaru',
          'epic_kurona': 'Kurona',
          'epic_hiori': 'Hiori',
          'raro_isagi': 'Isagi',
          'raro_chigiri': 'Chigiri',
          'raro_igaguri': 'Igaguri'
        };

        const estiloNombre = estilosMap[estiloValue];

        if (!client.estilosSeleccionados.has(messageId)) {
          client.estilosSeleccionados.set(messageId, new Map());
        }

        client.estilosSeleccionados.get(messageId).set(userId, estiloNombre);

        const mensaje = await interaction.channel.messages.fetch(messageId);
        const datos = client.posicionesSeleccionadas.get(messageId);
        
        if (datos) {
          const posicionId = datos.usuariosAPosiciones.get(userId);
          if (posicionId) {
            datos.posicionesOcupadas.set(posicionId, `<@${userId}> (${estiloNombre})`);

            const embed = new EmbedBuilder()
              .setTitle("⚽ Selección de Posiciones del Club")
              .setDescription("**Jugadores, elijan su posición:**\n\n" +
                `🔹 **CF** - ${datos.posicionesOcupadas.get('pos_cf') || 'Delantero Centro'}\n` +
                `🔹 **LW** - ${datos.posicionesOcupadas.get('pos_lw') || 'Extremo Izquierdo'}\n` +
                `🔹 **RW** - ${datos.posicionesOcupadas.get('pos_rw') || 'Extremo Derecho'}\n` +
                `🔹 **MC** - ${datos.posicionesOcupadas.get('pos_mc') || 'Medio Centro'}\n` +
                `🔹 **GK** - ${datos.posicionesOcupadas.get('pos_gk') || 'Portero'}`)
              .setColor("Blue")
              .setFooter({ text: "Presiona el botón de tu posición" });

            await mensaje.edit({ embeds: [embed] });
          }
        }

        await interaction.update({
          content: `✅ Elegiste el estilo: **${estiloNombre}**`,
          components: []
        });
      }
    }

    if (interaction.isButton()) {
      const posiciones = {
        'pos_cf': { nombre: 'CF - Delantero Centro', label: 'CF', emoji: '⚽' },
        'pos_lw': { nombre: 'LW - Extremo Izq.', label: 'LW', emoji: '⚡' },
        'pos_rw': { nombre: 'RW - Extremo Der.', label: 'RW', emoji: '⚡' },
        'pos_mc': { nombre: 'MC - Medio Centro', label: 'MC', emoji: '🎯' },
        'pos_gk': { nombre: 'GK - Portero', label: 'GK', emoji: '🧤' }
      };

      if (interaction.customId === 'salir_posicion') {
        const messageId = interaction.message.id;
        const userId = interaction.user.id;

        if (!client.posicionesSeleccionadas.has(messageId)) {
          return interaction.reply({
            content: '❌ No tienes ninguna posición asignada.',
            ephemeral: true
          });
        }

        const datos = client.posicionesSeleccionadas.get(messageId);
        
        if (!datos.usuarios.has(userId)) {
          return interaction.reply({
            content: '❌ No tienes ninguna posición asignada.',
            ephemeral: true
          });
        }

        let posicionLiberada = null;
        for (const [pos, jugador] of datos.posicionesOcupadas.entries()) {
          if (datos.usuariosAPosiciones && datos.usuariosAPosiciones.get(userId) === pos) {
            posicionLiberada = posiciones[pos].nombre;
            datos.posicionesOcupadas.delete(pos);
            datos.usuariosAPosiciones.delete(userId);
            break;
          }
        }

        datos.usuarios.delete(userId);

        const embed = new EmbedBuilder()
          .setTitle("⚽ Selección de Posiciones del Club")
          .setDescription("**Jugadores, elijan su posición:**\n\n" +
            `🔹 **CF** - ${datos.posicionesOcupadas.get('pos_cf') || 'Delantero Centro'}\n` +
            `🔹 **LW** - ${datos.posicionesOcupadas.get('pos_lw') || 'Extremo Izquierdo'}\n` +
            `🔹 **RW** - ${datos.posicionesOcupadas.get('pos_rw') || 'Extremo Derecho'}\n` +
            `🔹 **MC** - ${datos.posicionesOcupadas.get('pos_mc') || 'Medio Centro'}\n` +
            `🔹 **GK** - ${datos.posicionesOcupadas.get('pos_gk') || 'Portero'}`)
          .setColor("Blue")
          .setFooter({ text: "Presiona el botón de tu posición" });

        const row1 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('pos_cf')
              .setLabel(datos.posicionesOcupadas.has('pos_cf') 
                ? `CF - ${datos.posicionesOcupadas.get('pos_cf')}` 
                : 'CF - Delantero Centro')
              .setStyle(datos.posicionesOcupadas.has('pos_cf') ? ButtonStyle.Secondary : ButtonStyle.Primary)
              .setEmoji('⚽')
              .setDisabled(datos.posicionesOcupadas.has('pos_cf')),
            new ButtonBuilder()
              .setCustomId('pos_lw')
              .setLabel(datos.posicionesOcupadas.has('pos_lw') 
                ? `LW - ${datos.posicionesOcupadas.get('pos_lw')}` 
                : 'LW - Extremo Izq.')
              .setStyle(datos.posicionesOcupadas.has('pos_lw') ? ButtonStyle.Secondary : ButtonStyle.Primary)
              .setEmoji('⚡')
              .setDisabled(datos.posicionesOcupadas.has('pos_lw')),
            new ButtonBuilder()
              .setCustomId('pos_rw')
              .setLabel(datos.posicionesOcupadas.has('pos_rw') 
                ? `RW - ${datos.posicionesOcupadas.get('pos_rw')}` 
                : 'RW - Extremo Der.')
              .setStyle(datos.posicionesOcupadas.has('pos_rw') ? ButtonStyle.Secondary : ButtonStyle.Primary)
              .setEmoji('⚡')
              .setDisabled(datos.posicionesOcupadas.has('pos_rw'))
          );

        const row2 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('pos_mc')
              .setLabel(datos.posicionesOcupadas.has('pos_mc') 
                ? `MC - ${datos.posicionesOcupadas.get('pos_mc')}` 
                : 'MC - Medio Centro')
              .setStyle(datos.posicionesOcupadas.has('pos_mc') ? ButtonStyle.Secondary : ButtonStyle.Success)
              .setEmoji('🎯')
              .setDisabled(datos.posicionesOcupadas.has('pos_mc')),
            new ButtonBuilder()
              .setCustomId('pos_gk')
              .setLabel(datos.posicionesOcupadas.has('pos_gk') 
                ? `GK - ${datos.posicionesOcupadas.get('pos_gk')}` 
                : 'GK - Portero')
              .setStyle(datos.posicionesOcupadas.has('pos_gk') ? ButtonStyle.Secondary : ButtonStyle.Danger)
              .setEmoji('🧤')
              .setDisabled(datos.posicionesOcupadas.has('pos_gk'))
          );

        const row3 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('salir_posicion')
              .setLabel('Salir de mi posición')
              .setStyle(ButtonStyle.Danger)
              .setEmoji('❌')
          );

        await interaction.message.edit({ embeds: [embed], components: [row1, row2, row3] });

        await interaction.reply({
          content: `✅ <@${userId}> salió de la posición **${posicionLiberada}**`,
          ephemeral: false
        });
        return;
      }

      if (posiciones[interaction.customId]) {
        const messageId = interaction.message.id;
        const userId = interaction.user.id;
        const posicionId = interaction.customId;

        if (!client.posicionesSeleccionadas.has(messageId)) {
          client.posicionesSeleccionadas.set(messageId, {
            usuarios: new Set(),
            posicionesOcupadas: new Map(),
            usuariosAPosiciones: new Map()
          });
        }

        const datos = client.posicionesSeleccionadas.get(messageId);

        if (datos.usuarios.has(userId)) {
          return interaction.reply({
            content: '❌ Ya elegiste una posición. Solo puedes elegir una vez.',
            ephemeral: true
          });
        }

        if (datos.posicionesOcupadas.has(posicionId)) {
          const jugadorQueOcupa = datos.posicionesOcupadas.get(posicionId);
          return interaction.reply({
            content: `❌ Esta posición ya está ocupada por **${jugadorQueOcupa}**`,
            ephemeral: true
          });
        }

        datos.usuarios.add(userId);
        datos.posicionesOcupadas.set(posicionId, `<@${userId}>`);
        datos.usuariosAPosiciones.set(userId, posicionId);

        const embed = new EmbedBuilder()
          .setTitle("⚽ Selección de Posiciones del Club")
          .setDescription("**Jugadores, elijan su posición:**\n\n" +
            `🔹 **CF** - ${datos.posicionesOcupadas.get('pos_cf') || 'Delantero Centro'}\n` +
            `🔹 **LW** - ${datos.posicionesOcupadas.get('pos_lw') || 'Extremo Izquierdo'}\n` +
            `🔹 **RW** - ${datos.posicionesOcupadas.get('pos_rw') || 'Extremo Derecho'}\n` +
            `🔹 **MC** - ${datos.posicionesOcupadas.get('pos_mc') || 'Medio Centro'}\n` +
            `🔹 **GK** - ${datos.posicionesOcupadas.get('pos_gk') || 'Portero'}`)
          .setColor("Blue")
          .setFooter({ text: "Presiona el botón de tu posición" });

        const row1 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('pos_cf')
              .setLabel(datos.posicionesOcupadas.has('pos_cf') 
                ? `CF - ${datos.posicionesOcupadas.get('pos_cf')}` 
                : 'CF - Delantero Centro')
              .setStyle(datos.posicionesOcupadas.has('pos_cf') ? ButtonStyle.Secondary : ButtonStyle.Primary)
              .setEmoji('⚽')
              .setDisabled(datos.posicionesOcupadas.has('pos_cf')),
            new ButtonBuilder()
              .setCustomId('pos_lw')
              .setLabel(datos.posicionesOcupadas.has('pos_lw') 
                ? `LW - ${datos.posicionesOcupadas.get('pos_lw')}` 
                : 'LW - Extremo Izq.')
              .setStyle(datos.posicionesOcupadas.has('pos_lw') ? ButtonStyle.Secondary : ButtonStyle.Primary)
              .setEmoji('⚡')
              .setDisabled(datos.posicionesOcupadas.has('pos_lw')),
            new ButtonBuilder()
              .setCustomId('pos_rw')
              .setLabel(datos.posicionesOcupadas.has('pos_rw') 
                ? `RW - ${datos.posicionesOcupadas.get('pos_rw')}` 
                : 'RW - Extremo Der.')
              .setStyle(datos.posicionesOcupadas.has('pos_rw') ? ButtonStyle.Secondary : ButtonStyle.Primary)
              .setEmoji('⚡')
              .setDisabled(datos.posicionesOcupadas.has('pos_rw'))
          );

        const row2 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('pos_mc')
              .setLabel(datos.posicionesOcupadas.has('pos_mc') 
                ? `MC - ${datos.posicionesOcupadas.get('pos_mc')}` 
                : 'MC - Medio Centro')
              .setStyle(datos.posicionesOcupadas.has('pos_mc') ? ButtonStyle.Secondary : ButtonStyle.Success)
              .setEmoji('🎯')
              .setDisabled(datos.posicionesOcupadas.has('pos_mc')),
            new ButtonBuilder()
              .setCustomId('pos_gk')
              .setLabel(datos.posicionesOcupadas.has('pos_gk') 
                ? `GK - ${datos.posicionesOcupadas.get('pos_gk')}` 
                : 'GK - Portero')
              .setStyle(datos.posicionesOcupadas.has('pos_gk') ? ButtonStyle.Secondary : ButtonStyle.Danger)
              .setEmoji('🧤')
              .setDisabled(datos.posicionesOcupadas.has('pos_gk'))
          );

        const row3 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('salir_posicion')
              .setLabel('Salir de mi posición')
              .setStyle(ButtonStyle.Danger)
              .setEmoji('❌')
          );

        await interaction.message.edit({ embeds: [embed] });

        const pos = posiciones[interaction.customId];

        const selectMenu1 = new StringSelectMenuBuilder()
          .setCustomId(`estilo_selector_${messageId}`)
          .setPlaceholder('Elige tu estilo de juego')
          .addOptions(
            new StringSelectMenuOptionBuilder().setLabel('🌟 Maestros - Loki').setDescription('Categoría: Maestros').setValue('maestros_loki').setEmoji('🌟'),
            new StringSelectMenuOptionBuilder().setLabel('🌟 Maestros - Lavinho').setDescription('Categoría: Maestros').setValue('maestros_lavinho').setEmoji('🌟'),
            new StringSelectMenuOptionBuilder().setLabel('💎 Generacional - Don Lorenzo').setDescription('Categoría: Generacional').setValue('generacional_don_lorenzo').setEmoji('💎'),
            new StringSelectMenuOptionBuilder().setLabel('💎 Generacional - Sae').setDescription('Categoría: Generacional').setValue('generacional_sae').setEmoji('💎'),
            new StringSelectMenuOptionBuilder().setLabel('💎 Generacional - Kaiser').setDescription('Categoría: Generacional').setValue('generacional_kaiser').setEmoji('💎'),
            new StringSelectMenuOptionBuilder().setLabel('💎 Generacional - Bunny').setDescription('Categoría: Generacional').setValue('generacional_bunny').setEmoji('💎'),
            new StringSelectMenuOptionBuilder().setLabel('🏆 Clase Mundial - Charles').setDescription('Categoría: Clase Mundial').setValue('clase_mundial_charles').setEmoji('🏆'),
            new StringSelectMenuOptionBuilder().setLabel('🏆 Clase Mundial - NEL Isagi').setDescription('Categoría: Clase Mundial').setValue('clase_mundial_nel_isagi').setEmoji('🏆'),
            new StringSelectMenuOptionBuilder().setLabel('🏆 Clase Mundial - NEL Nagi').setDescription('Categoría: Clase Mundial').setValue('clase_mundial_nel_nagi').setEmoji('🏆'),
            new StringSelectMenuOptionBuilder().setLabel('🏆 Clase Mundial - NEL Rin').setDescription('Categoría: Clase Mundial').setValue('clase_mundial_nel_rin').setEmoji('🏆'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - NEL Bachira').setDescription('Categoría: Mítica').setValue('mitica_nel_bachira').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - Kunigami').setDescription('Categoría: Mítica').setValue('mitica_kunigami').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - NEL Reo').setDescription('Categoría: Mítica').setValue('mitica_nel_reo').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - King').setDescription('Categoría: Mítica').setValue('mitica_king').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - Aiku').setDescription('Categoría: Mítica').setValue('mitica_aiku').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - Shidou').setDescription('Categoría: Mítica').setValue('mitica_shidou').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('⚔️ Mítica - Yukimiya').setDescription('Categoría: Mítica').setValue('mitica_yukimiya').setEmoji('⚔️'),
            new StringSelectMenuOptionBuilder().setLabel('🔥 Legendario - Nagi').setDescription('Categoría: Legendario').setValue('legendario_nagi').setEmoji('🔥'),
            new StringSelectMenuOptionBuilder().setLabel('🔥 Legendario - Karasu').setDescription('Categoría: Legendario').setValue('legendario_karasu').setEmoji('🔥'),
            new StringSelectMenuOptionBuilder().setLabel('🔥 Legendario - Otoya').setDescription('Categoría: Legendario').setValue('legendario_otoya').setEmoji('🔥'),
            new StringSelectMenuOptionBuilder().setLabel('✨ Epic - Bachira').setDescription('Categoría: Epic').setValue('epic_bachira').setEmoji('✨'),
            new StringSelectMenuOptionBuilder().setLabel('✨ Epic - Gagamaru').setDescription('Categoría: Epic').setValue('epic_gagamaru').setEmoji('✨'),
            new StringSelectMenuOptionBuilder().setLabel('✨ Epic - Kurona').setDescription('Categoría: Epic').setValue('epic_kurona').setEmoji('✨'),
            new StringSelectMenuOptionBuilder().setLabel('✨ Epic - Hiori').setDescription('Categoría: Epic').setValue('epic_hiori').setEmoji('✨')
          );

        const selectMenu2 = new StringSelectMenuBuilder()
          .setCustomId(`estilo_selector_2_${messageId}`)
          .setPlaceholder('Más estilos...')
          .addOptions(
            new StringSelectMenuOptionBuilder().setLabel('⭐ Raro - Isagi').setDescription('Categoría: Raro').setValue('raro_isagi').setEmoji('⭐'),
            new StringSelectMenuOptionBuilder().setLabel('⭐ Raro - Chigiri').setDescription('Categoría: Raro').setValue('raro_chigiri').setEmoji('⭐'),
            new StringSelectMenuOptionBuilder().setLabel('⭐ Raro - Igaguri').setDescription('Categoría: Raro').setValue('raro_igaguri').setEmoji('⭐')
          );

        const rowEstilo1 = new ActionRowBuilder().addComponents(selectMenu1);
        const rowEstilo2 = new ActionRowBuilder().addComponents(selectMenu2);

        await interaction.reply({
          content: `${pos.emoji} Elegiste la posición: **${pos.nombre}**\n\nAhora elige tu estilo de juego:`,
          components: [rowEstilo1, rowEstilo2],
          ephemeral: true
        });
      }
    }
  },
};
