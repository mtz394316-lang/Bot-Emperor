const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("sancion")
        .setDescription("Registrar una sanción (solo staff)")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)

        // --- OPCIONES REQUERIDAS ---
        .addStringOption(option =>
            option.setName("nombre")
                .setDescription("Nombre del sancionado")
                .setRequired(true))
        .addStringOption(option =>
            option.setName("usuario")
                .setDescription("Usuario o ID del sancionado")
                .setRequired(true))
        .addStringOption(option =>
            option.setName("cargo")
                .setDescription("Cargo o rol del sancionado")
                .setRequired(true))
        .addStringOption(option =>
            option.setName("tipo")
                .setDescription("Tipo de sanción aplicada")
                .addChoices(
                    { name: "Advertencia verbal", value: "Advertencia verbal" },
                    { name: "Amonestación", value: "Amonestación" },
                    { name: "Suspensión", value: "Suspensión" },
                    { name: "Expulsión", value: "Expulsión" },
                    { name: "Otra", value: "Otra" }
                )
                .setRequired(true))
        .addStringOption(option =>
            option.setName("motivo")
                .setDescription("Motivo de la sanción")
                .setRequired(true))

        // --- OPCIONAL ---
        .addStringOption(option =>
            option.setName("duracion")
                .setDescription("Duración de la sanción (si aplica)")
                .setRequired(false)),

    run: async (client, interaction) => {
        // Verifica roles permitidos
        const allowedRoles = [
            "☾︎🔰☽︎ 𝘼𝙙𝙢𝙞𝙣 ☾︎🔰☽︎",
            "☾︎💎☽︎ 𝙈𝙤𝙙 ☾︎💎☽︎",
            "☾︎⭐☽︎ 𝙃𝙞𝙜𝙝𝙩 𝙈𝙤𝙙 ☾︎⭐☽︎"
        ];

        const hasAllowedRole = interaction.member.roles.cache.some(r => allowedRoles.includes(r.name));

        if (!hasAllowedRole) {
            return interaction.reply({
                content: "❌ No tienes permiso para usar este comando.",
                ephemeral: true
            });
        }

        // Obtener opciones
        const nombre = interaction.options.getString("nombre");
        const usuario = interaction.options.getString("usuario");
        const cargo = interaction.options.getString("cargo");
        const tipo = interaction.options.getString("tipo");
        const motivo = interaction.options.getString("motivo");
        const duracion = interaction.options.getString("duracion") || "No aplica";

        // Canal donde se guarda
        const sancionesChannel = interaction.guild.channels.cache.find(ch => ch.name === "║・🚫・𝗦𝗮𝗻𝗰𝗶𝗼𝗻𝗲𝘀");
        if (!sancionesChannel) {
            return interaction.reply({
                content: "⚠️ No encontré el canal `║・🚫・𝗦𝗮𝗻𝗰𝗶𝗼𝗻𝗲𝘀`. Revisa que el nombre coincida exactamente.",
                ephemeral: true
            });
        }

        // Embed con los datos
        const sancionEmbed = new EmbedBuilder()
            .setColor(0xff0000)
            .setTitle("📑 Registro de Sanción")
            .addFields(
                { name: "📝 Datos Generales", value: 
`**Nombre del sancionado:** ${nombre}  
**Identificación / Usuario:** ${usuario}  
**Cargo / Rol:** ${cargo}` },

                { name: "📅 Datos de la Sanción", value: 
`**Tipo de sanción aplicada:** ${tipo}  
**Duración:** ${duracion}` },

                { name: "📌 Motivo de la Sanción", value: motivo },

                { name: "📂 Evidencias Adjuntas", value: 
`▢ Capturas de pantalla  
▢ Testigos presenciales (opcional)` },

                { name: "👤 Responsable de la Sanción", value: 
`**Nombre / Usuario:** ${interaction.user}  
**Cargo / Rol:** Staff autorizado  
**Firma / Aprobación:** (Staff de alto rango)` },
            )
            .setFooter({ text: "Sistema de Registro de Sanciones" })
            .setTimestamp();

        // Enviar al canal
        await sancionesChannel.send({ embeds: [sancionEmbed] });

        // Confirmación privada
        return interaction.reply({
            content: `✅ La sanción fue registrada correctamente en ${sancionesChannel}.`,
            flags:
    MessageFlags.Ephemeral
        });
    }
}