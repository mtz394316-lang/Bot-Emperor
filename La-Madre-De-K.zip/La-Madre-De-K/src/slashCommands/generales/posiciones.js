const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("amis")
        .setDescription("Elige tu posición en el club"),
    run: async (client, interaction) => {
        
        const embed = new EmbedBuilder()
            .setTitle("⚽ Selección de Posiciones del Club")
            .setDescription("**Jugadores, elijan su posición:**\n\n🔹 **CF** - Delantero Centro\n🔹 **LW** - Extremo Izquierdo\n🔹 **RW** - Extremo Derecho\n🔹 **MC** - Medio Centro\n🔹 **GK** - Portero")
            .setColor("Blue")
            .setFooter({ text: "Presiona el botón de tu posición" });

        const row1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('pos_cf')
                    .setLabel('CF - Delantero Centro')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('⚽'),
                new ButtonBuilder()
                    .setCustomId('pos_lw')
                    .setLabel('LW - Extremo Izq.')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('⚡'),
                new ButtonBuilder()
                    .setCustomId('pos_rw')
                    .setLabel('RW - Extremo Der.')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('⚡')
            );

        const row2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('pos_mc')
                    .setLabel('MC - Medio Centro')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🎯'),
                new ButtonBuilder()
                    .setCustomId('pos_gk')
                    .setLabel('GK - Portero')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🧤')
            );

        const row3 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('salir_posicion')
                    .setLabel('Salir de mi posición')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('❌')
            );

        return interaction.reply({
            embeds: [embed],
            components: [row1, row2, row3]
        });
    }
}
