const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('elpeor')
    .setDescription('Muestra quién es el peor del Emperors'),

  async run(client, interaction) {
    const random = Math.random();
    const userId = random < 0.9 ? '1389090413490602117' : '1136111776698744852';

    await interaction.reply({
      content: `El peor del Emperors es <@${userId}>.`,
      allowedMentions: { users: [userId] }
    });
  }
};